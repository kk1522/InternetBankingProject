import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'BankingProject';
  username:string="Robert";
  accountNumber:number=10003;
  ngOnInit(): void {
    sessionStorage.setItem("user",this.username);
  }

  
}
