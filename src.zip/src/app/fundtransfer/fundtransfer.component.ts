import { Component, OnInit } from '@angular/core';
import { AppComponent } from '../app.component';
import { FundtransferserviceService } from '../fundtransferservice.service';
import { Account } from '../payee-menu/Account';
import { Payee } from '../payee-menu/Payee';
import { PayeeServiceService } from '../payee-service.service';


@Component({
  selector: 'app-fundtransfer',
  templateUrl: './fundtransfer.component.html',
  styleUrls: ['./fundtransfer.component.css']
})
export class FundtransferComponent implements OnInit {

  constructor(private payeeServ:PayeeServiceService,private fundSer:FundtransferserviceService) { }
 
  data:any;
  appObj:AppComponent = new AppComponent();
  username:number=this.appObj.accountNumber;
  payeeArray:Payee[]=[];
  payeeObj:Payee = new Payee();
  pAccNum:number=0;
  payeeAccount:Account=new Account();
  selfAccount:Account=new Account();
  transferAmount:number=0;
  msg:string="";
  
  getPayeebyAccount(){
    this.payeeServ.getPayeeService(this.username).subscribe(
      (data:Payee[])=>{
        this.payeeArray=data;
      }
    );
  }
  
  getAccountDetails(){
    this.fundSer.getAccountService(this.pAccNum).subscribe(
      (data:Account)=>{
        this.payeeAccount = data;
      }
    );
    this.fundSer.getAccountService(this.username).subscribe(
      (data:Account)=>{
        this.selfAccount=data;
      }
    );
  }

  transferFunds(){
    this.getAccountDetails();
    this.payeeAccount.balance=this.payeeAccount.balance+this.transferAmount;
    this.selfAccount.balance=this.selfAccount.balance-this.transferAmount;

    this.fundSer.setAccountService(this.selfAccount).subscribe(
      (data:any)=>{
        this.msg=data;
      },
      (err)=>{
        console.log(err);
      }
    );
    this.fundSer.setAccountService(this.payeeAccount).subscribe(
      (data:any)=>{
        this.msg=data;
      },
      (err)=>{
        console.log(err);
      }
    );
  }
  
  ngOnInit(): void {
    this.getPayeebyAccount();
  }
  


}
