import { Account } from "./Account";

export class Payee{
    payeeId:number=0;
    payeeName:string="";
    payeeAccountNumber:number=0;
    nickName:string="";
    account:Account=new Account();
}