import { ThisReceiver } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { PayeeServiceService } from '../payee-service.service';
import { Account } from './Account';
import { Payee } from './Payee';
import { PayeeDTO } from './PayeeDTO';

@Component({
  selector: 'app-payee-menu',
  templateUrl: './payee-menu.component.html',
  styleUrls: ['./payee-menu.component.css']
})
export class PayeeMenuComponent implements OnInit {
  payeeType:String="";
  show:boolean=false;
  v:boolean=false;
  a:boolean=false;
  d:boolean=false;
  msg:string="";
  id:number=0;
  user:string=JSON.stringify(sessionStorage.getItem("user"));
  errorMsg:string="";
  error:Boolean=false;
  confirmAcc:number=0;
  
  constructor(private payeeServ:PayeeServiceService) {

   }
  menuIdentifier:string="";
  payee:Payee = new Payee();
  payeeArray:Payee[]=[];
  accountName:string="";
 //account: Account=new Account();

  ngOnInit(): void {
    
    this.getPayeebyAccount();
   
  }

  getPayeebyAccount(){
    this.payeeServ.getPayeeService(10003).subscribe(
      (data:Payee[])=>{
        this.payeeArray=data;
      }
    );
    

  }
  
  deletePayee(payeeIdDelete:number){
    console.log("deletePayee()");
    this.payeeServ.deletePayeeService(payeeIdDelete).subscribe(
      (data:any)=>{
          this.msg=data;
      },(err)=>{
        console.log(err);
      }
    );
  }

  payeeDTO: PayeeDTO = new PayeeDTO();

  addPayee(){
    console.log("addPayee called")
    // this.account.accountNumber=10001;
    
    this.payeeDTO.payeeToAdd=this.payee;
    this.payeeDTO.targetAccountNumber=10003;

    console.log("addPayee called"+this.payee.account.accountNumber);
    console.log(this.payee)
    this.payeeServ.addPayeeService(this.payeeDTO).subscribe(
      (data:any)=>{
        this.msg=data;
      }
    );
  }
  validateAcc(){
    if(this.payee.payeeAccountNumber!=this.confirmAcc){
      this.errorMsg="Account Number does not match";
      this.error=true;
    }
    else{
      this.error=false;
    }
  }
  showView(){
    this.v=true;
    this.a=false;
    this.d=false;
  }
  showAdd(){
    this.a=true;
    this.d=false;
    this.v=false;
  }
  showDelete(){
    this.d=true;
    this.a=false;
    this.v=false;
  }
  toggleIfsc(){
    console.log("toggle");
    console.log(this.payeeType);
    console.log(this.menuIdentifier);
    if(this.payeeType==="Own Bank Account"){
        this.show=false;
    }
    else if(this.payeeType==="Other Bank Account"){
      this.show=true;
    }
    
  }

}
