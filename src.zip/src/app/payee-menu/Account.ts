import { Payee } from "./Payee";

export class Account{
    accountNumber:number=0;
    password:string="";
    balance:number=0;
    accountHolderName:string="";
    payee:Payee[]=[];
}




// @Id
// 	@Column(name="account_number")
// 	private Integer accountNumber;
// 	private String password;
// 	private Float balance;
// 	private String accountHolderName;
	
// 	@OneToMany(mappedBy="account", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
// 	List<Payee> payee = new ArrayList<Payee>();
	