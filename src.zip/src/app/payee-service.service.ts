import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Account } from './payee-menu/Account';
import { Payee } from './payee-menu/Payee';
import { PayeeDTO } from './payee-menu/PayeeDTO';

@Injectable({
  providedIn: 'root'
})
export class PayeeServiceService {

  baseUrl:String="http://localhost:8080/payee"
  constructor(private myHttp:HttpClient) { 
  }

  addPayeeService(payee:PayeeDTO):Observable<string>{
    console.log("in service"+payee.targetAccountNumber);
    return this.myHttp.post<string>(this.baseUrl+"/addPayee",payee);
  }
  getPayeeService(Acc:number) : Observable<Payee[]>{
    return this.myHttp.get<Payee[]>(this.baseUrl+"/getPayee/"+Acc);
  }
  deletePayeeService(pId:number):Observable<any>{
    return this.myHttp.post<any>(this.baseUrl+"/removePayee/"+pId,{responseType:'text' as 'json'});
  }
}
