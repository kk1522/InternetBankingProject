package com.sbi.project.layer3;

import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
@Repository
public class BaseRepoImpl implements BaseRepository {
	@PersistenceContext
	EntityManager entityManager;
	
	BaseRepoImpl()
	{
		System.out.println("Base DAOImpl const()......");
	}
	@Transactional
	public void persist(Object obj) {
		// TODO Auto-generated method stub
		entityManager.persist(obj);
	}

	@Transactional
	public void merge(Object obj) {
		// TODO Auto-generated method stub
		entityManager.merge(obj);
	}

	@Transactional
	public void remove(Object obj) {
		// TODO Auto-generated method stub
		entityManager.remove(obj);
	}

	
	public <AnyType> AnyType find(Class<AnyType> className, Serializable primaryKey) {
		// TODO Auto-generated method stub
		AnyType e = entityManager.find(className,primaryKey);
		return e;
	}

	@Override
	public <AnyType> List<AnyType> findAll(int accNum, Class<AnyType> className) {
		// TODO Auto-generated method stub
		TypedQuery<AnyType> typedQuery=entityManager.createQuery("from Payee p where p.account.accountNumber=:x",className);
		typedQuery.setParameter("x",accNum);
		return typedQuery.getResultList();
	}

}
