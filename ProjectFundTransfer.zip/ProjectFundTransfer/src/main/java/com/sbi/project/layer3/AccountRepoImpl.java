package com.sbi.project.layer3;

import org.springframework.stereotype.Repository;

import com.sbi.project.layer2.Account;

@Repository
public class AccountRepoImpl extends BaseRepoImpl implements AccountRepository {

	@Override
	public Account getAccount(int accountNumber) {
		return super.find(Account.class,accountNumber);
		 
	}

	@Override
	public void setAccount(Account account) {
		super.merge(account);
	}

}
