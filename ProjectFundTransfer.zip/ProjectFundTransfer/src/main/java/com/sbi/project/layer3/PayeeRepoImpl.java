package com.sbi.project.layer3;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.sbi.project.layer2.Payee;
@Repository
public class PayeeRepoImpl extends BaseRepoImpl implements PayeeRepository {

	@Transactional
	public void addPayee(Payee payeeObj) {
		// TODO Auto-generated method stub
		System.out.println("addPayeeRepo()");
           super.persist(payeeObj);
	}

	@Transactional
	public void deletePayee(int payeeId) {
		// TODO Auto-generated method stub
		Payee payeeObj = super.find(Payee.class, payeeId);
		super.remove(payeeObj);
	}

	@Override
	public Payee findPayee(int payeeId) {
		// TODO Auto-generated method stub
		return super.find(Payee.class, payeeId);
	}

	@Override
	public List<Payee> findAllPayee(int accountNumber) {
		// TODO Auto-generated method stub
		return super.findAll(accountNumber, Payee.class);
		
	}

}
