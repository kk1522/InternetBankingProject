package com.sbi.project.layer2;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="project_account")
public class Account {

	@Id
	@Column(name="account_number")
	private Integer accountNumber;
	private String password;
	private Float balance;
	private String accountHolderName;
	
	@OneToMany(mappedBy="account")
	List<Payee> payee = new ArrayList<Payee>();

	public Integer getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Integer accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Float getBalance() {
		return balance;
	}

	public void setBalance(Float balance) {
		this.balance = balance;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	@JsonIgnore
	public List<Payee> getPayee() {
		return payee;
	}

	public void setPayee(List<Payee> payee) {
		this.payee = payee;
	}

	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", password=" + password + ", balance=" + balance
				+ ", accountHolderName=" + accountHolderName + ", payee=" + payee + "]";
	}
	
	

}

