package com.sbi.project.layer5;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.project.layer2.Payee;
import com.sbi.project.layer4.PayeeService;

@CrossOrigin
@RestController
@RequestMapping("/payee")
public class PayeeController {

	@Autowired
	PayeeService payeeServ;
	PayeeController(){
		System.out.println("PayeeController()");
	}
	@RequestMapping("/test")
	public String payeeCntrl() {
		return "payee Controller accessed";
	}

	@RequestMapping("/getPayee/{accNo}")
	public List<Payee> getApplicants(@PathVariable("accNo") int accountNumber){
		System.out.println("getApplicant");
		return payeeServ.findAllPayee(accountNumber);
	}
	@PostMapping("/addPayee")
	public void addPayee(@RequestBody PayeeDTO payeeDTO) {
		System.out.println("add payee controller"+payeeDTO);
		payeeServ.addPayeeService(payeeDTO.payeeToAdd,payeeDTO.targetAccountNumber);
	}
	@RequestMapping("/removePayee/{pId}")
	public void removePayee(@PathVariable ("pId") int pId) {
		System.out.println("remove payee");
		payeeServ.deletePayeeService(pId);
	}
}
