package com.sbi.project.layer4;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.project.layer2.Account;
import com.sbi.project.layer3.AccountRepository;
@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	AccountRepository accRepo;
	@Override
	public Account getAccountService(int accountNumber) {
		return accRepo.getAccount(accountNumber);
	}

	@Override
	public void setAccountService(Account account) {
		accRepo.setAccount(account);
	}

}
