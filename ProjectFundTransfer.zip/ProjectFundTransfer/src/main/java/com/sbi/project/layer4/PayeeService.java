package com.sbi.project.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sbi.project.layer2.Payee;
@Service
public interface PayeeService {
	void addPayeeService(Payee payeeObj);
	void deletePayeeService(int payeeId);
	Payee findPayee(int payeeId);
	List<Payee> findAllPayee(int accountNumber);
	
}
